<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\DB;

/*
|--------------------------------------------------------------------------
| RUTAS DE LA API
|--------------------------------------------------------------------------
| Este archivo define las rutas necesarias para el sistema de tareas.
| Todas responden en formato JSON, tal como lo exige la tarea.
|
| Rutas incluidas:
|   ✔ GET    /tareas        → Leer todas las tareas
|   ✔ POST   /tareas        → Guardar una nueva tarea
|   ✔ DELETE /tareas/{id}   → Eliminar una tarea por ID
|
| La tabla utilizada es "tareas" dentro de la base de datos "tareas_db".
| Campos requeridos:
|   - id
|   - titulo
|
*/

/*======================================================================
| GET /tareas
|-----------------------------------------------------------------------
| Devuelve todas las tareas almacenadas en la tabla "tareas".
| Esta ruta es consumida por AngularJS mediante $http.get().
| Retorna un arreglo JSON con todas las tareas.
======================================================================*/
Route::get('/tareas', function () {
    return DB::table('tareas')->get();
});


/*======================================================================
| POST /tareas
|-----------------------------------------------------------------------
| Recibe una nueva tarea desde AngularJS.
| El campo recibido es "titulo", enviado mediante JSON.
|
| Ejemplo de JSON recibido:
|   { "titulo": "Mi nueva tarea" }
|
| Inserta la tarea en la base de datos y devuelve un mensaje JSON.
======================================================================*/
Route::post('/tareas', function (Request $request) {

    DB::table('tareas')->insert([
        'titulo' => $request->titulo
    ]);

    return response()->json(['mensaje' => 'Tarea guardada']);
});


/*======================================================================
| DELETE /tareas/{id}
|-----------------------------------------------------------------------
| Elimina una tarea según su ID.
| AngularJS envía el ID en la URL mediante $http.delete().
|
| Ejemplo:
|   DELETE /tareas/5
|
| Si la tarea existe, se elimina y se devuelve un mensaje JSON.
======================================================================*/
Route::delete('/tareas/{id}', function ($id) {

    DB::table('tareas')->where('id', $id)->delete();

    return response()->json(['mensaje' => 'Tarea eliminada']);
});
