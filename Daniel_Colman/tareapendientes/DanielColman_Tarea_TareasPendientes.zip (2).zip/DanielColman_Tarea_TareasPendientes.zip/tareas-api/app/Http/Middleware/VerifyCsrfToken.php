<?php

namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as Middleware;

class VerifyCsrfToken extends Middleware
{
    /**
     * The URIs that should be excluded from CSRF verification.
     *
     * @var array<int, string>
     */
    /*
|--------------------------------------------------------------------------
| Excepciones de CSRF
|--------------------------------------------------------------------------
|
| AngularJS no envía token CSRF, así que debemos excluir
| las rutas de la API para evitar errores 419.
|
*/
protected $except = [
    'api/tareas',     // Ruta para guardar tareas
    'api/tareas/*',   // Ruta para borrar tareas
];

}
