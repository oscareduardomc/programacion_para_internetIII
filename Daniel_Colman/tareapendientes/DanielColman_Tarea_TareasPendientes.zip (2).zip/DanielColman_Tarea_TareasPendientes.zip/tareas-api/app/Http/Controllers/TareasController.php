<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TareasController extends Controller
{
    public function index()
    {
        return DB::table('tareas')->get();
    }

    public function store(Request $request)
    {
        DB::table('tareas')->insert([
            'titulo' => $request->input('titulo'),
        ]);

        return response()->json(['mensaje' => 'Tarea guardada']);
    }

    public function destroy($id)
    {
        DB::table('tareas')->where('id', $id)->delete();

        return response()->json(['mensaje' => 'Tarea eliminada']);
    }
}
